package org.example;


import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.nd4j.evaluation.classification.Evaluation;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.SplitTestAndTrain;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.learning.config.Adam;

import java.io.File;

public class BodySize {
    public static void main(String[] args) throws Exception {
        // Step 1: Load and preprocess the dataset
        File file = new File("./csv/body_size.csv");
        RecordReader recordReader = new CSVRecordReader();
        recordReader.initialize(new FileSplit(file));
        DataSetIterator iterator = new RecordReaderDataSetIterator(recordReader, 1, 1, 1, true);
        DataSet allData = iterator.next();
        allData.shuffle();
        int numFeatures = allData.numInputs();
        int numClasses = allData.numOutcomes();

        // Step 2: Split the data into training and test sets
        double splitRatio = 0.6;
        SplitTestAndTrain split = allData.splitTestAndTrain(splitRatio);
        DataSet trainingData = split.getTrain();
        DataSet testData = split.getTest();

        // Step 3: Define and configure the neural network
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(123)
                .updater(new Adam())
                .list()
                .layer(new DenseLayer.Builder()
                        .nIn(numFeatures)
                        .nOut(1)
                        .activation(Activation.RELU)
                        .weightInit(WeightInit.XAVIER)
                        .build())
                .layer(new DenseLayer.Builder()
                        .nIn(1)
                        .nOut(numClasses)
                        .activation(Activation.SOFTMAX)
                        .weightInit(WeightInit.XAVIER)
                        .build())
                //.setLossFn(LossFunctions.LossFunction.MCXENT)
                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();
        model.setListeners(new ScoreIterationListener(100));

        // Step 4: Train the neural network
        int numEpochs = 1000;
        for (int epoch = 0; epoch < numEpochs; epoch++) {
            model.fit(trainingData);
        }

        // Step 5: Evaluate the model on the test set
        Evaluation evaluation = new Evaluation(numClasses);
        INDArray output = model.output(testData.getFeatures());
        evaluation.eval(testData.getLabels(), output);
        System.out.println("Test Accuracy: " + evaluation.accuracy());

        // Step 6: Make predictions
        INDArray input = Nd4j.create(new double[]{180}); // Input feature
        INDArray predicted = model.output(input);
        int predictedClass = predicted.argMax(1).getInt(0);
        System.out.println("Predicted Class: " + predictedClass);
    }
}
