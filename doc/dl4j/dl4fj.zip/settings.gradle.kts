rootProject.name = "dl4j-eval"

